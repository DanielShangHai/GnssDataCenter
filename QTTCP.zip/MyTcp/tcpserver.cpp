#include "tcpserver.h"
#include <QDebug>
#include <QHostAddress>
const int kPort = 6000;

TcpServer::TcpServer(QObject *parent) :
    QObject(parent),
    m_tcpserver(NULL)
{
    initserver();
}
void TcpServer::initserver()
{
    //启动一个tcpserver
    m_tcpserver = new QTcpServer(this);
    //监听
    if(!m_tcpserver->listen(QHostAddress::Any, kPort))
    {
        qDebug() << "listen error: " ;
        return;
    }
    else
    {
        qDebug() << "server start is ok!";
    }
    connect(m_tcpserver, SIGNAL(newConnection()), this, SLOT(slot_newConnection()));
}
void TcpServer::slot_newConnection()
{
   //得到每一个连接成功的客户段socket套接字
    QTcpSocket *newtcpsocket = m_tcpserver->nextPendingConnection();

    if( NULL == newtcpsocket )
    {
        qDebug() << "socket is error";
        return ;
    }
    m_tcpsocket = newtcpsocket;

    QHostAddress address = newtcpsocket->peerAddress();//取出新客户端的IP地址

    QString clientIp = address.toString();

    qDebug() << "clientIp: " << clientIp;
    connect(newtcpsocket, SIGNAL(readyRead()), this, SLOT(slot_readdata()));
}
void TcpServer::slot_readdata()
{
    QTcpSocket *newtcpsocket = static_cast<QTcpSocket*>(this->sender());
    QString recvbuf = "";
    recvbuf = newtcpsocket->readAll();
    QString clientip = newtcpsocket->peerAddress().toString();
    qDebug() << "user " << clientip << "sendText: " << recvbuf;
    newtcpsocket->write(recvbuf.toLatin1(),recvbuf.length());
}
