#ifndef TCPSERVER_H
#define TCPSERVER_H

#include <QObject>
#include <QTcpSocket>
#include <QTcpServer>

class TcpServer : public QObject
{
    Q_OBJECT
public:
    explicit TcpServer(QObject *parent = 0);
    //~TcpServer();

signals:
public slots:
    void slot_newConnection();
    void slot_readdata();

private:
    QTcpServer *m_tcpserver;

    QTcpSocket *m_tcpsocket;
private:
    void initserver();
};

#endif // TCPSERVER_H
