#include "tcpserver.h"

TcpServer::TcpServer(QWidget *parent,Qt::WindowFlags f)
    : QDialog(parent,f)
{
    setWindowTitle(tr("TCP Server"));//设置标题

    ContentListWidget = new QListWidget;

    PortLabel = new QLabel(tr("端口"));
    PortLineEdit = new QLineEdit;

    CreateBtn = new QPushButton(tr("CreatChatRoom"));

    mainLayout = new QGridLayout(this); //使用网格布局的方式进行布局
    mainLayout->addWidget(ContentListWidget,0,0,1,2);
    mainLayout->addWidget(PortLabel,1,0);
    mainLayout->addWidget(PortLineEdit,1,1);
    mainLayout->addWidget(CreateBtn,2,0,1,2);
    port=8010;
        PortLineEdit->setText(QString::number(port));//设置 PortLineEdit的数值为8010
      connect(CreateBtn,SIGNAL(clicked()),this,SLOT(slotStart())); //连接函数创建监听线程

}
TcpServer::~TcpServer()
{

}
void TcpServer::slotStart()
{
           workThread=new WorkThread();
           workThread->start();
}


