#include "workthread.h"
#include <QtDebug>
WorkThread::WorkThread()
{
}

void WorkThread::run()//填写要做的事情
{


}
